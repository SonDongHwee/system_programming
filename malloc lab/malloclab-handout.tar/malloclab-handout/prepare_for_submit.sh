#!/bin/bash

tar -zcvf assign3.tar.gz mm.c
